/**
 * @author Daniel Novak
 * Course: CSC-331-003
 * Date: 4/16/2025
 *
 * ***NOTE!!!*** The actual controller files will likely function quite differently
 * than this, given that this test file uses the console for output while the actual
 * main program will use JavaFX GUIs and controllers. This file is simply to ensure that inheritance
 * between the files and other important base class functionalities are working properly.
 */

import java.util.ArrayList;

public class BaseFilesTesting {
    public static void main(String[] args){

        // Declare counter variable for loops
        int counter;

        System.out.println("-----------------------------");
        System.out.println("BASE CLASS FILES TESTING");
        System.out.println("-----------------------------");

        // First, we'll test to make sure that Doctor objects can be created properly,
        // work in an ArrayList properly, and print properly.
        System.out.println("Doctor object and ArrayList test");
        System.out.println("-----------------------------");
        System.out.println();

        // Create some Doctors
        Doctor docOne = new Doctor("Mario Mario", "453-674-3234", 40, "Internal Medicine", 35);
        Doctor docTwo = new Doctor("Luigi Mario", "453-679-1239", 40, "Internal Medicine", 12);
        Doctor docThree =  new Doctor("Peach Mario", "453-695-3429", 40, "Internal Medicine", 35);

        // Store the Doctors in an ArrayList
        ArrayList<Doctor> myDoctors = new ArrayList<>();
        myDoctors.add(docOne);
        myDoctors.add(docTwo);
        myDoctors.add(docThree);



        // Print out the details of each Doctor.
        //
        // EXPECTED OUTPUT:
        // Name: [Name]
        // Phone number: [Phone]
        // Age: [Age]
        // Specialty: [Specialty]
        // Years experience: [yearsExp]

        for (counter=0; counter<myDoctors.size(); counter++){
            Doctor currentDoc = myDoctors.get(counter);
            System.out.println(currentDoc);
        }

        // Next, we'll apply the same tests we just did with Doctor to Patient.
        // (So, this means making Patient objects, making a Patient ArrayList, and printing
        // Patient details)
        System.out.println("-----------------------------");
        System.out.println("Patient object and ArrayList test");
        System.out.println("-----------------------------");
        System.out.println();

        // Create some Patients
        Patient patOne = new Patient("Tom Servo", "134-345-2342", 37, new ArrayList<>() {{add("Headache"); add("Fatigue");}});
        Patient patTwo = new Patient("Crow T. Robot", "123-342-3452" , 36, new ArrayList<>() {{add("Mechanical Issues"); add("Fatigue");}});
        Patient patThree = new Patient("GPC", "124-345-3452", 36, new ArrayList<>() {{add("Anxiety"); add("Fatigue");}});

        // Store the Patients in an ArrayList
        ArrayList<Patient> myPatients = new ArrayList<>();
        myPatients.add(patOne);
        myPatients.add(patTwo);
        myPatients.add(patThree);

        // Print out the details of each Patient.
        //
        // EXPECTED OUTPUT:
        // Name: [Name]
        // Phone number: [Phone]
        // Age: [Age]
        // Health issues: [Health issues]

        for (counter=0; counter<myPatients.size(); counter++){
            Patient currentPat = myPatients.get(counter);
            System.out.println(currentPat);
        }

        // Next, we'll test out getHealthIssues, addIssue, removeIssue on patient one's (Tom Servo) healthIssues ArrayList.

        // ***NOTE***: The main program will not worry about getting nor modifying a patient's list of health issues.
        // This is simply to ensure that these three subclass methods function correctly since they work differently than
        // traditional getter/setter methods.
        System.out.println("-----------------------------");
        System.out.println("Patient health issues retrieval and modification test");
        System.out.println("-----------------------------");

        System.out.printf("%ngetHealthIssues on patient one: %s%n", patOne.getHealthIssues().toString());
        System.out.println("\nAdding Anxiety to patient one's health issues list...");
        patOne.addIssue("Anxiety");
        System.out.printf("getHealthIssues on patient one: %s%n", patOne.getHealthIssues().toString());
        System.out.println("\nRemoving Anxiety from patient one's health issues list...");
        patOne.removeIssue("Anxiety");
        System.out.printf("getHealthIssues on patient one: %s%n%n", patOne.getHealthIssues().toString());

        // Finally, we'll test out Appointment objects, including Appointment creation,
        // an Appointment ArrayList, and Appointment printing.
        System.out.println("-----------------------------");
        System.out.println("Appointment object and ArrayList test");
        System.out.println("-----------------------------");

        // Create some Appointments
        // apptOne with Dr. Mario and Patient Crow T. Robot
        Appointment apptOne = new Appointment("In-Person", "Physical Exam", "2025-04-17", "11:00 AM", docOne, patTwo);
        // apptTwo with Dr. Luigi and Patient Tom Servo
        Appointment apptTwo = new Appointment("Virtual", "Consultation", "2025-04-17", "2:00 PM", docTwo, patOne);
        // apptThree with Dr. Peach and Patient GPC
        Appointment apptThree = new Appointment("In-Person", "New Patient Establishment", "2025-04-17", "4:00 PM", docThree, patThree);

        // Store the Appointments in an ArrayList
        ArrayList<Appointment> myAppts = new ArrayList<>();
        myAppts.add(apptOne);
        myAppts.add(apptTwo);
        myAppts.add(apptThree);

        // Print out the details of each Appointment.
        //
        // EXPECTED OUTPUT:
        // Appt Location: [Location]
        // Appt Type: [Type]
        // Appt Date: [Date]
        // Appt Time: [Time]
        // Appt Doctor: [Doctor's name]
        // Appt Patient: [Patient's name]

        for (counter=0; counter<myAppts.size(); counter++){
            Appointment currentAppt = myAppts.get(counter);
            System.out.println(currentAppt);
        }
    }
}
