CSC-331 Group 7 Project Developed by:
- James Frink
- Ayushman Singh
- Daniel Novak
- Martin Shurtleff

Our Doctor's Appointment Booking System allows patients to schedule appointments with doctors. It also allows them to view their upcoming appointments and cancel any of their appointments.

!!!NOTE!!!: The program is ran through MainApplication.java, but you'll need to open the entire project folder in IntelliJ or your IDE of choice before running that file. Just opening MainApplication.java without opening the project first will likely result in the SDK and other JavaFX functionalities not being set up properly, which means MainApplication.java will not be able to run. (If you're using IntelliJ, MainApplication.java in the project directory should have a "C in a circle" icon with a green triangle in the upper right of the icon. This means it can be run. It should not have a coffee cup icon.)

On the log-in screen, use one of the following names:
- Tom Servo
- Crow T. Robot
- Cambot